import java.io.*;
import java.net.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.sql.*;

public class InsertDB extends Thread
{

	public static void main(String[] args) throws Exception
	{
    DUtil.Insert();          
	}


}



class DUtil
{
	static String DRIVER_NAME   = null;
	static String DB_URL        = null;
	static String USER_NAME     = "";
	static String PASSWORD      = "";
	static String TABLE_NAME    = "";

	public static Connection getConnection()
	{
		if (null == DRIVER_NAME )
		{
			DRIVER_NAME = "oracle.jdbc.driver.OracleDriver";
			DB_URL      = "jdbc:oracle:thin:@172.25.1.32:1521:OKFB";
			USER_NAME   = "cowon";
			PASSWORD    = "cowon123";

			if (USER_NAME   == null) USER_NAME  = "";
			if (PASSWORD    == null) PASSWORD   = "";
		}

		try{
			Class.forName (DRIVER_NAME);
			if (USER_NAME == null || USER_NAME.length() == 0)
				return DriverManager.getConnection(DB_URL);
			else
				return DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return null;
	}
	
	/* Insert */
	public static boolean Insert()
	{
		Connection          con = null;
		PreparedStatement   pstmt = null;

		String QRY = "INSERT INTO TRADE_REQUEST_BIN  ("+
							"REQ_DATE , REQ_TIME , SVC_TYPE , BANK_CODE, "+
							"COMP_CODE, SEQ_NO   , MSG_CODE , SEND_FLAG, RECV_FLAG, "+
							"SEND_DATE, SEND_TIME, RECV_DATE, RECV_TIME, SEND_MSG , "+
							"RECV_MSG, BIN_DATA ) VALUES ("  +
							"?, ?, ?, ?, ?,  ?, ?, ?, ?, ?,  ?, ?, ?, ?, ?,?)";
							
		int cnt = 0;
		try {
			con = getConnection();
			con.setAutoCommit(false);

			pstmt = con.prepareStatement(QRY);

			pstmt.setString (1, "20160713"       );
			pstmt.setString (2, "150000" );
			pstmt.setString (3, "P" );
			pstmt.setString (4, "027"     );
			pstmt.setString (5, "50026469"     );
			pstmt.setString (6, "900002"     );
			pstmt.setString (7, "0600601"     );
			pstmt.setString (8, "N"     );
			pstmt.setString (9,"N"    );
			pstmt.setString (10,""    );
			pstmt.setString (11,""    );
			pstmt.setString (12,""    );
			pstmt.setString (13,""    );
			pstmt.setString (14,"         50026469  0600601190000220180516202216                                     027             D0000001  7110004524401   1        20160510     Y3046062311   123451234512345                     50026469  027       050026469           01jpg 0043913                                                 ");
			pstmt.setString (15,""    );
			
			File Blob = new File("/home/firmbk/jgwang/java/RFB_PRF/test/image.jpg");
			FileInputStream is = new FileInputStream (Blob);
			FileInputStream is2 = is;
			pstmt.setBinaryStream(16, is2, (int) Blob.length());

			cnt = pstmt.executeUpdate();

			con.commit();
			return true;
		} catch(Throwable t) {
			t.printStackTrace();
		} finally {
			try {if(pstmt!=null){pstmt.close();pstmt= null;}}catch(Exception e){}
			try {if(con !=null) {con.close( );}}catch(Exception e){}
		}
		return false;
	}

	
}

