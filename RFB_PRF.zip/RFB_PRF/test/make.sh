#!/usr/bin/sh
JAVA_HOME=/usr/java6
INSTALL_HOME=..

CLASSPATH=.:$INSTALL_HOME:$INSTALL_HOME/lib/sqljdbc.jar:$INSTALL_HOME/lib/ojdbc14.jar:$INSTALL_HOME/lib/mysql-connector-java-5.1.6-bin.jar

$JAVA_HOME/bin/javac -d . *.java


$JAVA_HOME/bin/java -classpath $CLASSPATH InsertDB
