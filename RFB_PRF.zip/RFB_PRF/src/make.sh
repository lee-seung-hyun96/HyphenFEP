#!/usr/bin/sh
JAVA_HOME=/usr/java6

$JAVA_HOME/bin/javac -d ../classes *.java
