package ksnet.ksrfb;

import java.io.*;
import java.net.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.sql.*;

public class FirmBypassDB extends Thread
{
	private String msg_info[] = new String[10];
	private InputStream     bin_in = null;

	public static void main(String[] args) throws Exception
	{
		CUtil.setConfig(args[0]);

		long 	SLEEP_TIME = Long.parseLong(CUtil.get("SLEEP_TIME"));						/* request sleep time */
		int 	THREAD_DELAY_TIME = 1000/Integer.parseInt(CUtil.get("SEND_CNT_PER_SEC"));	/* db select sleep time */

		LUtil.println("START["+CUtil.get("SEND_CNT_PER_SEC")+"]");

		new LogDeleteTimer().start();

		while(true)
		{
			String send_info[] = DUtil.Select_SendData();

			if (send_info[0].equals("0000"))
			{
				new FirmBypassDB(send_info).start();
				Thread.sleep(THREAD_DELAY_TIME);
			}
			else	/*  db select not found */
			{
				Thread.sleep(SLEEP_TIME);
			}
		}
	}

	public FirmBypassDB(String[] send_info)
	{
		System.arraycopy(send_info, 0, this.msg_info, 0, send_info.length);

		if ((send_info[2].equals("PRW") || send_info[2].equals("PRD")) && send_info[7].equals("0600601"))
		{
			CopyInputStream cis = new CopyInputStream(DUtil.bin_in);
			this.bin_in = cis.getCopy();
		}
	}

	public void run()
	{
		DataOutputStream    cli_out = null;
		DataInputStream     cli_in = null;
		DataOutputStream    serv_out = null;
		DataInputStream     serv_in = null;
		String              send_msg = null;
		String              recv_msg = null;
		String              host;
		int                 port, timeout;
		int                 msg_len = 0;
		int                 len;
		Socket              ss = null;

		int     read_len = 0, rest_len = 0, rtn_len = 0;

		try {
			String ip_param = "KSNET_IP_"+msg_info[2];
			String port_param = "KSNET_PORT_"+msg_info[2];

			this.msg_info[0] = "9999";
			this.msg_info[9] = " ";
			send_msg = this.msg_info[8];

			host = CUtil.get(ip_param);
			if (host == null)
			{
				throw new IOException("config undefined - (" + ip_param + ")!!");
			}
			port = Integer.parseInt(CUtil.get(port_param));
      				
			timeout = Integer.parseInt(CUtil.get("Timeout"));

			if (msg_info[2].equals("KEB"))
				msg_len = 2000;  /* KEB 2000bytes */
			else
				msg_len = 300;  /* 300bytes */

			byte[] sbuf = SUtil.ConvS2B(send_msg, msg_len, "ksc5601");

			LUtil.println("CLIENT->KSNET=[" + send_msg + "][L:" + sbuf.length + "] [" + host + ":"+port+"]");

			/* send to KSNET */
			ss = new Socket();
			ss.connect(new InetSocketAddress(host, port),2*1000); /* connect timeout */
			ss.setSoTimeout(timeout*1000);	/* read timeout */

			serv_out = new DataOutputStream(ss.getOutputStream());

			/* binary include msg_len */
			if (msg_info[2].equals("PRW") || msg_info[2].equals("PRD") || msg_info[2].equals("DBT"))
			{
				serv_out.write(String.format("%04d", msg_len).getBytes(), 0, 4);
				serv_out.flush();
			}

			serv_out.write(sbuf, 0, msg_len);
			serv_out.flush();

			/* proof binary send */
			if ((msg_info[2].equals("PRW") || msg_info[2].equals("PRD")) && msg_info[7].equals("0600601"))
			{
				int size = 0;
				int tot_size = 0;
				byte[]  bin_buf = new byte[2048];

				while((size = bin_in.read(bin_buf)) != -1)
				{
					/* LUtil.println("DEBUG BIN_DATA =[" + size + "]"); */
					tot_size+=size;
					serv_out.write(bin_buf, 0, size);
					serv_out.flush();  
				}
				LUtil.println("BIN_DATA TOTAL SIZE:"+tot_size+"bytes");
			}

			/* receive from KSNET */
			serv_in = new DataInputStream(ss.getInputStream());

			/* binary include msg_len */
			if (msg_info[2].equals("PRW") || msg_info[2].equals("PRD") || msg_info[2].equals("DBT"))
			{
				byte[]  tbuf = new byte[4];
				if((rtn_len = serv_in.read(tbuf, 0, 4)) <= 0)
				{
					throw new IOException("Read(recv) error - (" + rtn_len + ")!!");
				}
			
				rest_len = Integer.parseInt(SUtil.toHanX(tbuf, 0, rtn_len));
			}
			else
			{
				rest_len = msg_len;
			}

			read_len = 0;

			byte[]  rbuf = new byte[msg_len];
			while(true)
			{
				if((rtn_len = serv_in.read(rbuf, read_len, rest_len)) <= 0)
				{
					throw new IOException("Read(recv) error - (" + rtn_len + ")!!");
				}

				read_len = read_len + rtn_len;
				rest_len = rest_len - rtn_len;

				if( rest_len == 0 ) break;
			}

			recv_msg = SUtil.ConvB2S(rbuf, 0, msg_len, "ksc5601");

			this.msg_info[0] = "0000";
			this.msg_info[9] = recv_msg;

			DUtil.Update_RecvData(this.msg_info);   /* update recv_msg  */

			LUtil.println("KSNET->CLIENT=[" + recv_msg + "][L:"+rbuf.length+"]");

		}catch(SocketTimeoutException e) {
			this.msg_info[0] = "TIME";
			DUtil.Update_RecvData(this.msg_info);
			LUtil.println("ERROR:"+e.getMessage()+" ["+send_msg+"]");
		}catch(ConnectException e) {
			this.msg_info[0] = "CONE";
			DUtil.Update_RecvData(this.msg_info);
			LUtil.println("ERROR:"+e.getMessage()+" ["+send_msg+"]");
		}catch (Exception e) {
			this.msg_info[0] = "9999";
			DUtil.Update_RecvData(this.msg_info);
			LUtil.println("ERROR:"+e.getMessage()+" ["+send_msg+"]");
		}finally {
			try{if (serv_in != null) serv_in.close();}catch(Exception e){};
			try{if (serv_out != null) serv_out.close();}catch(Exception e){};
			try{if (ss != null) ss.close();}catch(Exception e){};
		}
	}
}

class LUtil
{
	static String LOG_DIR = null;
	private static synchronized boolean init()
	{
		if (null == LOG_FILE || CUtil.isNew())
		{

			LOG_DIR = CUtil.get("LOG_PATH");

			if (null == LOG_DIR) return false;

			File log_dir = new File(LOG_DIR);
			if (!log_dir.exists()) log_dir.mkdirs();
		}
		return true;
	}

	static Calendar LOG_CAL     = Calendar.getInstance();
	static String LOG_DT        = null;
	static String LOG_FILE      = null;

	private static synchronized void day_check(String curr_dt8)
	{
		if (LOG_DT == null || !LOG_DT.equals(curr_dt8))
		{

			StringBuffer sb = new StringBuffer();

			sb.append(LOG_DIR);
			if (!LOG_DIR.endsWith("/") && !LOG_DIR.endsWith("\\")) sb.append('/');

			sb.append(curr_dt8);
			sb.append(".log");

			LOG_FILE = sb.toString();

			LOG_DT = curr_dt8;
		}
	}

	public static void println(Object pstr)
	{
		if (!init())
		{
			System.out.println("ERROR LOG_PATH !!");
			return;
		}

		String curr_date = SUtil.getCurrDate();

		day_check(curr_date.substring(0,8));

		File openFile = new File(LOG_FILE);
		PrintStream out = null;

		try{
			if(openFile.exists()){
				out = new PrintStream(new FileOutputStream(LOG_FILE, true), true);
			}else{
				out = new PrintStream(new FileOutputStream(LOG_FILE), true);
			}
		}catch(Exception e){
			e.printStackTrace();
		}

		if (pstr instanceof Throwable)
		{
			Throwable tw = (Throwable)pstr;
			tw.printStackTrace(out);
			out.println();
		}else
		{
			StringBuffer sb = new StringBuffer();

			sb.append("[");
			sb.append(curr_date.substring(8,10)).append(":").append(curr_date.substring(10,12)).append(":").append(curr_date.substring(12,14));
			sb.append("]" );
			sb.append(pstr);

			out.println(sb.toString());
		}
		out.close();
	}
}

class CUtil
{
	static String config_file = null;
	static long lastModified = 0;

	public static Properties props = new Properties();

	public static synchronized void setConfig(String fpath)
	{
		if (!new File(fpath).exists()) throw new IllegalArgumentException("config=["+fpath+"]");
		config_file = fpath;
	}

	public static synchronized boolean isNew()
	{
		try
		{
			File f = new File(config_file);
			long m_lastModified = f.lastModified();

			if (m_lastModified > lastModified + 2000)
			{
				props.load(new FileInputStream(f));

				lastModified = m_lastModified;

				return true;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	public static String get(String kStr)
	{
		isNew();
		return props.getProperty(kStr);
	}
}

class DUtil
{
	static String DRIVER_NAME   = null;
	static String DB_URL        = null;
	static String USER_NAME     = "";
	static String PASSWORD      = "";
	static String TABLE_NAME    = "";

	static InputStream     bin_in = null;

	public static Connection getConnection()
	{
		if (null == DRIVER_NAME || CUtil.isNew())
		{
			DRIVER_NAME = CUtil.get("JDBC_DRIVER"   );
			DB_URL      = CUtil.get("JDBC_URL"      );
			USER_NAME   = CUtil.get("JDBC_USER"     );
			PASSWORD    = CUtil.get("JDBC_PASSWORD" );

			if (USER_NAME   == null) USER_NAME  = "";
			if (PASSWORD    == null) PASSWORD   = "";
		}

		try{
			Class.forName (DRIVER_NAME);
			if (USER_NAME == null || USER_NAME.length() == 0)
				return DriverManager.getConnection(DB_URL);
			else
				return DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
		}catch(Exception e)
		{
			LUtil.println(e);
		}
		return null;
	}
	
	public static boolean Update_RecvData(String[] msg_info)
	{
		Connection          con = null;
		PreparedStatement   pstmt = null;
		String recv_flag =  " ";
		String RecvDate     = new SimpleDateFormat("yyyyMMddHHmmss").format(new java.util.Date());
		TABLE_NAME          = CUtil.get("JDBC_TABLENAME");

		if (msg_info[0].equals("0000")) recv_flag = "Y";
		else if (msg_info[0].equals("CONE")) recv_flag = "C";  // connect error 
		else if (msg_info[0].equals("TIME")) recv_flag = "T";  // response timeout
		else recv_flag = "F"; 								

		String QRY = "UPDATE "+TABLE_NAME+" SET RECV_FLAG = ?, RECV_DATE = ?, RECV_TIME = ?, RECV_MSG = ? WHERE REQ_DATE = ? AND SVC_TYPE = ? AND BANK_CODE = ? AND COMP_CODE = ? AND SEQ_NO = ? AND MSG_CODE = ? AND SEND_FLAG = 'Y' AND RECV_FLAG = 'N' ";

		int cnt = 0;
		try {
			con = getConnection();
			con.setAutoCommit(false);

			pstmt = con.prepareStatement(QRY);

			pstmt.setString (1, recv_flag       );
			pstmt.setString (2, RecvDate.substring(0,8) );
			pstmt.setString (3, RecvDate.substring(8,14) );
			pstmt.setString (4, msg_info[9]     );
			pstmt.setString (5, msg_info[1]     );
			pstmt.setString (6, msg_info[2]     );
			pstmt.setString (7, msg_info[4]     );
			pstmt.setString (8, msg_info[5]     );
			pstmt.setString (9, msg_info[6]     );
			pstmt.setString (10, msg_info[7]    );

			cnt = pstmt.executeUpdate();

			con.commit();
			return true;
		} catch(Throwable t) {
			t.printStackTrace();
		} finally {
			try {if(pstmt!=null){pstmt.close();pstmt= null;}}catch(Exception e){}
			try {if(con !=null) {con.close( );}}catch(Exception e){}
		}
		return false;
	}

	public static String[] Select_SendData ()
	{
		Connection          con     = null;
		PreparedStatement   pstmt   = null;
		ResultSet           rs      = null;
		int                 cnt     = 0;
		String send_info[]  = {"9999", " ", " ", " ", " ", " ", " ", " ", " "} ;
		String RequestDate  = new SimpleDateFormat("yyyyMMddHHmmss").format(new java.util.Date());
		TABLE_NAME          = CUtil.get("JDBC_TABLENAME");

		/* db select */
		String QRY = "SELECT REQ_DATE, SVC_TYPE, BANK_CODE, COMP_CODE, SEQ_NO, MSG_CODE, SEND_MSG, BIN_DATA FROM " + TABLE_NAME + " WHERE REQ_DATE = ? AND SEND_FLAG = 'N' ORDER BY REQ_DATE, REQ_TIME";

		try {
			con = getConnection();
			con.setAutoCommit(false);

			pstmt = con.prepareStatement(QRY);

			pstmt.setString (1, RequestDate.substring(0,8) );

			rs = pstmt.executeQuery();

			while (rs.next()) {
				cnt++;
				send_info[0] = "0000";              
				send_info[1] = rs.getString(1);     /* request date */
				send_info[2] = rs.getString(2);     /* svc_type */
				send_info[3] = "0300";     			/* msg_len */
				send_info[4] = rs.getString(3);     /* bank_code */
				send_info[5] = rs.getString(4);     /* comp_code */
				send_info[6] = rs.getString(5);     /* seq_numb */
				send_info[7] = rs.getString(6);     /* msg_code */
				send_info[8] = rs.getString(7);     /* send_msg */

				if ((send_info[2].equals("PRW") || send_info[2].equals("PRD")) && send_info[7].equals("0600601"))
				{
					InputStream rs_in = rs.getBinaryStream(8);     			/* binary data */
					CopyInputStream cis = new CopyInputStream(rs_in);
					bin_in = cis.getCopy();
					rs_in.close();
				} 

				if (cnt >= 1) break;  
			}

			if (cnt < 1)
			{
				send_info[0] = "1404";  /* not found */
			}
			else
			{
				pstmt.close(); pstmt= null;

				QRY = "UPDATE " + TABLE_NAME + " SET SEND_FLAG = 'Y', SEND_DATE = ?, SEND_TIME = ? WHERE REQ_DATE = ? AND SVC_TYPE = ? AND BANK_CODE = ? AND COMP_CODE = ? AND SEQ_NO= ? AND MSG_CODE = ? ";

				pstmt = con.prepareStatement(QRY);

				pstmt.setString (1, RequestDate.substring(0,8) );
				pstmt.setString (2, RequestDate.substring(8,14) );
				pstmt.setString (3, send_info[1] );
				pstmt.setString (4, send_info[2] );
				pstmt.setString (5, send_info[4] );
				pstmt.setString (6, send_info[5] );
				pstmt.setString (7, send_info[6] );
				pstmt.setString (8, send_info[7] );

				cnt  = pstmt.executeUpdate();
				con.commit();
			}
		}catch(Throwable e) {
			send_info[0] = "9999";
			LUtil.println(e);
		} finally {
			try {if(pstmt!=null){pstmt.close();pstmt= null;}}catch(Exception e){}
			try {if(con !=null) {con.close( );}}catch(Exception e){}
			try {if(rs !=null) {rs.close( ); rs = null;}}catch(Exception e){}
		}
		return send_info;
	}
}

class SUtil
{
	static String getCurrDate() 
	{
		Calendar cal = Calendar.getInstance();
		StringBuffer sb = new StringBuffer();
		int li_yyyy,li_MM,li_dd,li_hour,li_min,li_sec;

		li_yyyy = cal.get(Calendar.YEAR); li_MM = cal.get(Calendar.MONTH); li_dd = cal.get(Calendar.DATE);
		li_hour = cal.get(Calendar.HOUR_OF_DAY); li_min = cal.get(Calendar.MINUTE); li_sec = cal.get(Calendar.SECOND);

		sb.append(li_yyyy).append(li_MM<9 ? "0" : "").append(li_MM + 1).append(li_dd<10 ? "0" : "").append(li_dd);
		sb.append(li_hour<10 ? "0" : "").append(li_hour).append(li_min<10 ? "0" : "").append(li_min).append(li_sec<10 ? "0" : "").append(li_sec);

		return sb.toString();
	}

	static String toHanX(byte[] bsrc, int idx, int len)
	{
		String str = toHan(bsrc, idx, len);
		if (str == null) return null;

		return str;
	}

	static String toHan(byte[] bsrc, int idx, int len)
	{
		try
		{
			String str = new String(bsrc, "ksc5601");
			return format(str, len, 'X');
		}catch(java.io.UnsupportedEncodingException ue){}

		return null;
	}

	static String format(String str, int len, char ctype)
	{
		byte[] buff;
		int filllen = 0;

		String          trim_str = null;
		StringBuffer    sb = new StringBuffer();

		buff = (str == null) ? new byte[0] : str.getBytes();

		filllen = len - buff.length;
		if (filllen < 0)
		{
			for(int i=0, j=0; j<len-4; i++)
			{
				j += (str.charAt(i) > 127) ? 2 : 1;
				sb.append(str.charAt(i));
			}
			trim_str = sb.toString();
			buff = trim_str.getBytes();
			filllen = len - buff.length;

			if (filllen <= 0) return new String(buff, 0, len);
			sb.setLength(0);
		}else
		{
			trim_str = str;
		}

		if(ctype == '9')	/* number */
		{
			for(int i = 0; i<filllen;i++) sb.append('0');
			sb.append(trim_str);
		}else		/* string */
		{
			for(int i = 0; i<filllen;i++) sb.append(' ');
			sb.insert(0, trim_str);
		}
		return sb.toString();
	}

	static byte[] ConvB2B(byte[] bsrc, int idx, int len, String src_encoding, String tgt_encoding)
	{
		try
		{
			String buf = new String(bsrc, idx, len, src_encoding);
			byte[] buf_enc = buf.getBytes(tgt_encoding);

			return buf_enc;
		}catch(java.io.UnsupportedEncodingException ue){}
		return null;
	}

	static String ConvB2S(byte[] bsrc, int idx, int len, String src_encoding)
	{
		try
		{
			String buf = new String(bsrc, idx, len, src_encoding);
			return format(buf, len, 'X');

		}catch(java.io.UnsupportedEncodingException ue){}

		return null;
	}

	static byte[] ConvS2B(String src, int tgt_len, String tgt_encoding)
	{
		try
		{
			byte[] nb = new byte[tgt_len];
			
			for (int i=0; i < tgt_len; i++)
			{
				nb[i]= 0x20;
			}

			byte[] buf = src.getBytes(tgt_encoding);

			int len = tgt_len;
			if (buf.length < tgt_len) len = buf.length; 	// over array size
			
			System.arraycopy(buf, 0, nb, 0, len);

			return nb;
		}catch(java.io.UnsupportedEncodingException ue){}

		return null;
	}

}

class LogDeleteTimer extends Thread
{
	public void run()
	{
		try {
			while(true)
			{
				deleteLogFile();
				Thread.sleep(1000*60);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	static String SS_LOG_HOME  = null;
	static int    SI_LOG_SAVE_DAY = 0;

	private void deleteLogFile()
	{
		String fnm = "deleteLogFile";

		long cmillis = System.currentTimeMillis();

		if (null == SS_LOG_HOME)
		{

			SS_LOG_HOME = CUtil.get("LOG_PATH");
			SI_LOG_SAVE_DAY = Integer.parseInt(CUtil.get("LOG_SAVE_DAYS"));


			if (null == SS_LOG_HOME)
			{
				LUtil.println(fnm + " ERROR : LOG_DIR_PATH!!");
				return;
			}
		}

		File dir = new File(SS_LOG_HOME);
		if (dir == null || !dir.isDirectory())
		{
			LUtil.println(fnm + " ERROR : LOG_DIR_PATH!!");
			return;
		}

		deleteOldFiles(dir, (cmillis-(86400000L*SI_LOG_SAVE_DAY)), true, false);
	}

	private void deleteOldFiles(File dir, long lastModified, boolean deleteSub, boolean deleteSubDir)
	{
		File[] fs = dir.listFiles();
		for(int i=0; i<fs.length; i++)
		{
			if (deleteSub && fs[i].isDirectory()) deleteOldFiles(fs[i], lastModified, true, deleteSubDir);
			if (fs[i].lastModified() < lastModified)
			{
				if (!fs[i].isDirectory() || deleteSubDir)
				{
					boolean rtn = fs[i].delete();
					//LUtil.println("====deleteOldFiles==== [" + rtn + ":"+fs[i].getName()+"]!!");;
				}
			}
		}
	}
}

class CopyInputStream
 {
	private InputStream _is;
	private ByteArrayOutputStream _copy = new ByteArrayOutputStream();

	public CopyInputStream(InputStream is)
	{
		_is = is;
		
		try
		{
			copy();
		}
		catch(IOException ex)
		{
			// do nothing
		}
	}

	private int copy() throws IOException
	{
		int read = 0;
		int chunk = 0;
		byte[] data = new byte[256];
		
		while(-1 != (chunk = _is.read(data)))
		{
			read += data.length;
			_copy.write(data, 0, chunk);
		}

		return read;
	}
		
	public InputStream getCopy()
	{
		return (InputStream)new ByteArrayInputStream(_copy.toByteArray());
	}
}
