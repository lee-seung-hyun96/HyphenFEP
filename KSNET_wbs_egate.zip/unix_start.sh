#!/usr/bin/ksh

JAVA_HOME=/usr/java6_64
INSTALL_HOME=`pwd`
CONFIG_FILE=./conf/config.ini

CLASSPATH=.:./classes

PROCESS_CNT=`ps -ef | egrep "DKSNET_RCV_ENC|DKSNET_SND_ENC" | grep -v -E "grep|check" | wc -l`

if (( $PROCESS_CNT == 0 ))
then
echo "run....."
	nohup $JAVA_HOME/bin/java -DKSNET_RCV_ENC -classpath $CLASSPATH KsnetRcvEnc $CONFIG_FILE & 
	nohup $JAVA_HOME/bin/java -DKSNET_SND_ENC -classpath $CLASSPATH KsnetSndEnc $CONFIG_FILE & 
else
	print "\n>>> [���] ���� KSNET EGATE ����" $PROCESS_CNT "���� ���� ���Դϴ�!!!"
	print "========================================================================"
	ps -ef | egrep "DKSNET_RCV_ENC|DKSNET_SND_ENC" | grep -v -E "grep|check"
	print "========================================================================"
fi
