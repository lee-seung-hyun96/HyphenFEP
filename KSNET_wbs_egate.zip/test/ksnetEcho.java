import java.io.*;
import java.net.*;
import java.util.*;

public class ksnetEcho extends Thread
{
	public static String Encoding = null;

	public static void main(String[] args) throws Exception
	{

		int port = Integer.parseInt(args[0]);

		System.out.println("Process Start LISTEN_PORT["+port +"]");
				
		ServerSocket ss = new ServerSocket(port);
	
		while(true)
		{
			Socket  cs = ss.accept();
			new ksnetEcho (cs).start();
		}
	}

	Socket cs;
	public ksnetEcho (Socket cs)
	{
		this.cs = cs;
	}

	public void run()
	{
		DataOutputStream    out         = null;
		DataInputStream     in          = null;
		byte[]	tmp_buf = new byte[2048];
		
		int read_len = 0, rtn_len = 0;

		try {
			System.out.println("Socket Accept!!");

			in = new DataInputStream(cs.getInputStream());

				if (0 >= (rtn_len = in.read(tmp_buf, read_len, 2048)))
				{
					throw new IOException("Read error - " + rtn_len + "read Byte!!");
				}
	
				read_len = read_len + rtn_len;
				byte[] read_buf = new byte[rtn_len];
				System.arraycopy(tmp_buf, 0, read_buf, 0, rtn_len);
				
				System.out.println("RCV_MSG=[" + new String(read_buf, "ksc5601") + "] [L:"+read_buf.length+"]");
				
				byte[] send_buf = new byte[rtn_len];
				send_buf = parseMsg(read_buf);
	
				out = new DataOutputStream(cs.getOutputStream());
				out.write(send_buf);
				out.flush();
	
				System.out.println("SND_MSG=[" + new String(send_buf, "ksc5601") + "] [L:"+send_buf.length+"]");

			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}finally{
			try{if (in != null) in.close();}catch(Exception e){};
			try{if (out != null) out.close();}catch(Exception e){};
			try{if (cs != null) cs.close();}catch(Exception e){};
		}
	}

	public byte[] parseMsg(byte[] byte_data) throws Exception
	{

		byte[] read_buf = (byte[])byte_data.clone();
		byte[] O_resp_code = {'0','0','0','0'};

		if (byte_data.length == 2000) /* KEB */
		{
			read_buf[23+1] = '1';
			System.arraycopy(O_resp_code, 0, read_buf, 51, 4);
		}
		else /* WON */
		{
			read_buf[19+2] = '1';
			System.arraycopy(O_resp_code, 0, read_buf, 47, 4);
		}

		return read_buf;
	}

}
