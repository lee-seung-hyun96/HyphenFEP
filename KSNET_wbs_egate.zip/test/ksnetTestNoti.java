/*  ������ : javac ksnetTestNoti.java */
/*  �ǻ�   : java ksnetTestNoti 127.0.0.1 28800 */
import java.io.*;
import java.net.*;
import java.util.*;

public class ksnetTestNoti
{
	public static void main(String[] args) throws Exception
	{
			Socket ss = null;
			DataOutputStream	serv_out		= null;
			DataInputStream		serv_in			= null;

			String host;
			int 	port;
			int 	timeout = 5;  	/* TIMEOUT */

			
			// ��ȭ�ŷ�����  
			String TestMsg = "         TESTBANK040200300100000120130206152001                000000                               572070034647   01200200000010000000000000000000028900Ȳ�Ѻ�������            00000000000000000000000000000000000000006505010097901  20130206152000                                                      ";

			//������� ������ȸ
			//String TestMsg = "KSNETVR  TESTBANK040900100150003520150608180026                                     004             61189013032002                                04                      0000000607400  10                    004                                                                                          ";
			//������� �Ա�
			//String TestMsg = "KSNETVR  TESTBANK040200300100000120130206152001                000000                               572070034647   01200200000010000000000000000000028900Ȳ�Ѻ�������            00000000000000000000000000000000000000006505010097901  20130206152000                                                      ";
			//��ȭ ����
			//String TestMsg = "TESTBANK TESTBANK    8880006011000006201803151317250000                                             181000012345    112018031513123400006USD000000212708500000000733018860�۷ι�(�׽�Ʈ)00000000000000088060XXŸ�����                        021846520+                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        ";

			if (args.length < 2) 
			{
				System.out.println ("Usage: java ksnetTestNoti 127.0.0.1 28800 \n");
				return;
			}

			host = args[0];
			port = Integer.parseInt(args[1]);

			byte[]	sbuf = TestMsg.getBytes();
			int 	msg_len = sbuf.length;
		
			try
			{
				/* �۽� */
				ss		=	new Socket();
				ss.setSoTimeout(5*1000);//read timeout
				ss.connect(new InetSocketAddress(host, port),timeout);//connect timeout	
																	
				serv_out = new DataOutputStream(ss.getOutputStream());
				serv_out.write(sbuf, 0, msg_len);
				serv_out.flush();
				System.out.println("SEND_MSG=[" + toHan(sbuf) + "]");
	
				/* ���� */
				serv_in = new DataInputStream(ss.getInputStream());
										
				int read_len = 0;
				int rtn_len = 0;
				
				if (msg_len != (rtn_len = serv_in.read(sbuf, read_len, msg_len)))
				{
					throw new IOException("Read(recv) error - (" + read_len + ")����!!");
				}
	
				System.out.println("RECV_MSG=[" + toHan(sbuf) + "]");
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
			}finally {
				try{if (serv_in != null) serv_in.close();}catch(Exception e){};
				try{if (serv_out != null) serv_out.close();}catch(Exception e){};
				try{if (ss != null) ss.close();}catch(Exception e){};
			}
	}
	static String toHan(byte[] bsrc)
	{
		try
		{
			return new String(bsrc, "ksc5601");
		}catch(java.io.UnsupportedEncodingException ue){}

		return null;
	}
}
