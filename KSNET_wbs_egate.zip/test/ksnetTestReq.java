/*  ������ : javac ksnetTestReq.java */
/*  �ǻ�   : java ksnetTestReq 127.0.0.1 27701 */
import java.io.*;
import java.net.*;
import java.util.*;

public class ksnetTestReq
{
	public static void main(String[] args) throws Exception
	{
			Socket ss = null;
			DataOutputStream	serv_out		= null;
			DataInputStream		serv_in			= null;

			String host;
			int 	port;
			int 	timeout = 5;  	/* TIMEOUT */

			String TestMsg = "";

			//WON
			TestMsg = "         TESTCALL  0800800100000120160425092147                                     004                                                                                                                                                                                                                     ";
		

			if (args.length < 2) 
			{
				System.out.println ("Usage: java ksnetTestReq 127.0.0.1 27701 \n");
				return;
			}

			host = args[0];
			port = Integer.parseInt(args[1]);

			byte[]	sbuf = TestMsg.getBytes();
			int 	msg_len = sbuf.length;
			
			try
			{
				/* �۽� */
				ss		=	new Socket();
				ss.setSoTimeout(5*1000);//read timeout
				ss.connect(new InetSocketAddress(host, port),timeout);//connect timeout	
				System.out.println("Connect OK=[" + host + "]["+port+"]");													
				serv_out = new DataOutputStream(ss.getOutputStream());
				serv_out.write(sbuf, 0, msg_len);
				serv_out.flush();
				System.out.println("SEND_MSG=[" + toHan(sbuf) + "]");
	
				/* ���� */
				serv_in = new DataInputStream(ss.getInputStream());
										
				int read_len = 0;
				int rtn_len = 0;
				
				if (msg_len != (rtn_len = serv_in.read(sbuf, read_len, msg_len)))
				{
					throw new IOException("Read(recv) error - (" + read_len + ")����!!");
				}
	
				System.out.println("RECV_MSG=[" + toHan(sbuf) + "]");
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
			}finally {
				try{if (serv_in != null) serv_in.close();}catch(Exception e){};
				try{if (serv_out != null) serv_out.close();}catch(Exception e){};
				try{if (ss != null) ss.close();}catch(Exception e){};
			}
	}
	static String toHan(byte[] bsrc)
	{
		try
		{
			return new String(bsrc, "ksc5601");
		}catch(java.io.UnsupportedEncodingException ue){}

		return null;
	}
}
