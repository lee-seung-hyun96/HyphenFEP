#!/usr/bin/sh
ps -ef|egrep "DKSNET_RCV_ENC|DKSNET_SND_ENC" |grep -v grep|awk '{print $2}'|xargs kill
