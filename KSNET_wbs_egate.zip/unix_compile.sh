#!/usr/bin/sh

JAVA_HOME=/usr/java6_64
INSTALL_HOME=`pwd`

CLASSPATH=$INSTALL_HOME/classes

echo "java compile...."
$JAVA_HOME/bin/javac -d ./classes src/*.java
