import java.io.*;
import java.net.*;
import java.util.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;

class LUtil
{
	static String LOG_DIR = null;
	private static synchronized boolean init()
	{
		if (null == LOG_FILE || CUtil.isNew())
		{
			LOG_DIR     = CUtil.get("LOG_DIR_PATH");
			if (null == LOG_DIR) return false;
		}
		return true;
	}

	static Calendar LOG_CAL     = Calendar.getInstance();
	static String  LOG_DT       = null;
	static String  LOG_FILE     = null;
	static String  LOG_PREFIX   = null;

	private static synchronized void day_check(String curr_dt8)
	{
		if (LOG_DT == null || !LOG_DT.equals(curr_dt8))
		{
			File log_dir_file = new File(LOG_DIR);
			if (!log_dir_file.exists())log_dir_file.mkdirs();

			StringBuffer sb = new StringBuffer();

			sb.append(LOG_DIR);
			if (!LOG_DIR.endsWith("/") && !LOG_DIR.endsWith("\\")) sb.append("/");
			sb.append(curr_dt8);
			sb.append(".log");

			LOG_FILE = sb.toString();

			LOG_DT = curr_dt8;
		}
	}
	
	private static synchronized void day_check(String prefix, String curr_dt8)
	{
		if (LOG_DT == null || LOG_PREFIX == null || !LOG_DT.equals(curr_dt8) || !LOG_PREFIX.equals(prefix))
		{
			File log_dir_file = new File(LOG_DIR);
			if (!log_dir_file.exists())log_dir_file.mkdirs();

			StringBuffer sb = new StringBuffer();

			sb.append(LOG_DIR);
			if (!LOG_DIR.endsWith("/") && !LOG_DIR.endsWith("\\")) sb.append("/");
			sb.append(curr_dt8);
			sb.append("_");
			sb.append(prefix);
			sb.append(".log");

			LOG_FILE = sb.toString();

			LOG_DT = curr_dt8;
			LOG_PREFIX = prefix;
		}
	}

	public static void println(Object pstr)
	{
		if (!init())
		{
			System.out.println("LOG_DIR_PATH ��������!!");
			return;
		}

		String curr_date = SUtil.getCurrDate();

		day_check(curr_date.substring(0,8));

		File openFile = new File(LOG_FILE);
		PrintStream out = null;

		try{
			if(openFile.exists()){
				out = new PrintStream(new FileOutputStream(LOG_FILE, true), true);
			}else{
				out = new PrintStream(new FileOutputStream(LOG_FILE), true);
			}

			if (pstr instanceof Throwable)
			{
				Throwable tw = (Throwable)pstr;
				tw.printStackTrace(out);
				out.println();
			}else{
				StringBuffer sb = new StringBuffer();

				sb.append("[");
				sb.append(curr_date.substring(8,10)).append(":").append(curr_date.substring(10,12)).append(":").append(curr_date.substring(12,14));
				sb.append("]" );
				sb.append(pstr);

				out.println(sb.toString());
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}finally {
			try{if (out != null) out.close();}catch(Exception e){};
		}
	}
	
	public static void println(String prefix, Object pstr)
	{
		if (!init())
		{
			System.out.println("LOG_DIR_PATH Setting Error");
			return;
		}

		String curr_date = SUtil.getCurrDate();

		day_check(prefix, curr_date.substring(0,8));

		File openFile = new File(LOG_FILE);
		PrintStream out = null;

		try{
			if(openFile.exists()){
				out = new PrintStream(new FileOutputStream(LOG_FILE, true), true);
			}else{
				out = new PrintStream(new FileOutputStream(LOG_FILE), true);
			}

			if (pstr instanceof Throwable)
			{
				Throwable tw = (Throwable)pstr;
				tw.printStackTrace(out);
				out.println();
			}else{
				StringBuffer sb = new StringBuffer();

				sb.append("[");
				sb.append(curr_date.substring(8,10)).append(":").append(curr_date.substring(10,12)).append(":").append(curr_date.substring(12,14));
				sb.append("]" );
				sb.append(pstr);

				out.println(sb.toString());
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}finally {
			try{if (out != null) out.close();}catch(Exception e){};
		}
	}
}



class CUtil
{
	static String config_file = null;
	static long lastModified  = 0;

	public static Properties props = new Properties();

	public static synchronized void setConfig(String fpath)
	{
		if (!new File(fpath).exists()) throw new IllegalArgumentException("ȯ������ ��� ����=["+fpath+"]");
		config_file = fpath;
	}

	public static synchronized boolean isNew()
	{
		try
		{
			File f = new File(config_file);
			long m_lastModified = f.lastModified();

			if (m_lastModified > lastModified + 2000)
			{
				props.load(new FileInputStream(f));

				lastModified = m_lastModified;

				return true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}

	public static String get(String kStr)
	{
		isNew();
		return props.getProperty(kStr);
	}
}


class SUtil
{
	static String getCurrDate()
	{
		Calendar cal = Calendar.getInstance();
		StringBuffer sb = new StringBuffer();
		int li_yyyy,li_MM,li_dd,li_hour,li_min,li_sec;

		li_yyyy = cal.get(Calendar.YEAR); li_MM = cal.get(Calendar.MONTH); li_dd = cal.get(Calendar.DATE);
		li_hour = cal.get(Calendar.HOUR_OF_DAY); li_min = cal.get(Calendar.MINUTE); li_sec = cal.get(Calendar.SECOND);

		//sb.append(Integer.toString(li_yyyy)).append(li_MM<9 ? "0" : "").append(Integer.toString(li_MM + 1)).append(li_dd<10 ? "0" : "").append(Integer.toString(li_dd));
		//sb.append(li_yyyy+"").append(li_MM<9 ? "0" : "").append(li_MM + 1+"").append(li_dd<10 ? "0" : "").append(li_dd+""); 
		sb.append(li_yyyy).append(li_MM<9 ? "0" : "").append(li_MM + 1).append(li_dd<10 ? "0" : "").append(li_dd);
		sb.append(li_hour<10 ? "0" : "").append(li_hour).append(li_min<10 ? "0" : "").append(li_min).append(li_sec<10 ? "0" : "").append(li_sec);

		return sb.toString();
	}

	static String toHanX(byte[] bsrc, int idx, int len)
	{
		String str = toHan(bsrc, idx, len);
		if (str == null) return null;

		return str.trim();
	}

	static String toHan(byte[] bsrc, int idx, int len)
	{
		try
		{
			return new String(bsrc, idx, len ,"ksc5601");
		}catch(java.io.UnsupportedEncodingException ue){}

		return null;
	}

	static String GetSvcCode(byte[] msg)
	{
		if(msg.length == 2000) return "2000";   //KEB
		else if (SUtil.toHan(msg, 0, 9).equals("KSNETVR  ")) return "4000"; //VR
		else if (SUtil.toHan(msg, 9, 3).equals("FCS") && SUtil.toHan(msg, 19, 7).equals("0600400") ) return "5000"; // FCS
		else if (SUtil.toHan(msg, 0, 9).equals("KSFC     ")|| SUtil.toHan(msg, 17, 4).equals("    ")) return "3000"; //SDS EBOND
		else if (SUtil.toHan(msg, 0, 9).equals("KSBPAY   ")) return "6000"; //KSBPAY
		else    return "1000";  //WON
	}
	static String GetSvcName(byte[] msg)
	{
		if(msg.length == 2000) return "KEB";   //KEB
		else if (SUtil.toHan(msg, 0, 9).equals("KSNETVR  ")) return "VAC"; //VR
		else if (SUtil.toHan(msg, 9, 3).equals("FCS") && SUtil.toHan(msg, 19, 7).equals("0600400") ) return "FCS"; // FCS
		else if (SUtil.toHan(msg, 0, 9).equals("KSFC     ")|| SUtil.toHan(msg, 17, 4).equals("    ")) return "EBD"; //SDS EBOND
		else    return "WON";  //WON
	}

}
class EUtil
{
	public static byte[] udecode_3des(byte[] b_key, byte[] ebytes) throws NoSuchAlgorithmException, InvalidKeyException,
			IllegalBlockSizeException, NoSuchPaddingException, BadPaddingException, IOException
	{
		SecretKeySpec skeySpec = new SecretKeySpec(b_key, "DESede");
		Cipher cipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");

		cipher.init(Cipher.DECRYPT_MODE, skeySpec);
		byte[] b_emsg = Base64.url64_decode(ebytes);
		byte[] b_dmsg = cipher.doFinal(b_emsg);

		return b_dmsg;
	}

	public static byte[] uencode_3des(byte[] b_key, byte[] pbytes) throws NoSuchAlgorithmException, InvalidKeyException,
			IllegalBlockSizeException, NoSuchPaddingException, BadPaddingException, IOException
	{
		SecretKeySpec skeySpec = new SecretKeySpec(b_key, "DESede");
		Cipher cipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");

		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		byte[] b_emsg = cipher.doFinal(pbytes);
		byte[] b_bmsg = Base64.url64_encode(b_emsg);

		return b_bmsg;
	}
}

class Base64
{
	
	protected static final char[] alphabet = {
		'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', // 0 to 7
		'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', // 8 to 15
		'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', // 16 to 23
		'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', // 24 to 31
		'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', // 32 to 39
		'o', 'p', 'q', 'r', 's', 't', 'u', 'v', // 40 to 47
		'w', 'x', 'y', 'z', '0', '1', '2', '3', // 48 to 55
		'4', '5', '6', '7', '8', '9', '+', '/'  // 56 to 63
	};

	protected static final int[] decodeTable = {
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 0 to 9
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 10 to 19
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 20 to 29
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 30 to 39
		-1, -1, -1, 62, -1, -1, -1, 63, 52, 53, // 40 to 49
		54, 55, 56, 57, 58, 59, 60, 61, -1, -1, // 50 to 59
		-1, -1, -1, -1, -1,  0,  1,  2,  3,  4, // 60 to 69
		 5,  6,  7,  8,  9, 10, 11, 12, 13, 14, // 70 to 79
		15, 16, 17, 18, 19, 20, 21, 22, 23, 24, // 80 to 89
		25, -1, -1, -1, -1, -1, -1, 26, 27, 28, // 90 to 99
		29, 30, 31, 32, 33, 34, 35, 36, 37, 38, // 100 to 109
		39, 40, 41, 42, 43, 44, 45, 46, 47, 48, // 110 to 119
		49, 50, 51                              // 120 to 122
	};

	public static char[] encode(String s) {
		return encode(s.getBytes());
	}

	/**
	 * convert bytes into a BASE64 encoded string
	 */
	public static char[] encode(byte[] bytes)
	{
		int sixbit;

		char[] output = new char[((bytes.length - 1) / 3 + 1) * 4];

		int outIndex = 0;
		int i = 0;

		while ((i + 3) <= bytes.length)
		{
			sixbit = (bytes[i] & 0xFC) >> 2;
			output[outIndex++] = alphabet[sixbit];

			sixbit = ((bytes[i] & 0x3) << 4) + ((bytes[i + 1] & 0xF0) >> 4);
			output[outIndex++] = alphabet[sixbit];

			sixbit = ((bytes[i + 1] & 0xF) << 2) + ((bytes[i + 2] & 0xC0) >> 6);
			output[outIndex++] = alphabet[sixbit];

			sixbit = bytes[i + 2] & 0x3F;
			output[outIndex++] = alphabet[sixbit];

			i += 3;
		}

		if (bytes.length - i == 2)
		{
			
			sixbit = (bytes[i] & 0xFC) >> 2;
			output[outIndex++] = alphabet[sixbit];

			
			sixbit = ((bytes[i] & 0x3) << 4) + ((bytes[i + 1] & 0xF0) >> 4);
			output[outIndex++] = alphabet[sixbit];

			
			sixbit = (bytes[i + 1] & 0xF) << 2;
			output[outIndex++] = alphabet[sixbit];

			
			output[outIndex++] = '=';
		} else
		if (bytes.length - i == 1) 
		{
			
			sixbit = (bytes[i] & 0xFC) >> 2;
			output[outIndex++] = alphabet[sixbit];

			
			sixbit = (bytes[i] & 0x3) << 4;
			output[outIndex++] = alphabet[sixbit];

			
			output[outIndex++] = '=';
			
			output[outIndex++] = '=';
		}

		return output;
	}

	public static char[] b2cs(byte[] ebytes)
	{
		char[] echars = new char[ebytes.length];
		for(int i=0; i<echars.length; i++) echars[i] = (char)ebytes[i];

		return echars;
	}

	public static byte[] c2bs(char[] echars)
	{
		byte[] ebytes = new byte[echars.length];
		for(int i=0; i<echars.length; i++) ebytes[i] = (byte)echars[i];

		return ebytes;
	}

	public static byte[] decode(byte[] ebytes)
	{
		return decode(b2cs(ebytes));
	}

	public static byte[] decode(String encoded)
	{
		return decode(encoded.toCharArray());
	}

	public static byte[] decode(char[] echars)
	{
		byte[] decoded = null;
		int decodedLength = (echars.length / 4 * 3);
		int invalid = 0;

		if (echars.length % 4 != 0)
		{
			System.err.println("It's not BASE64 encoded string.");
			return null;
		}
		if (echars[echars.length - 2] == '=')
		{
			invalid = 2;
		} else
		if (echars[echars.length - 1] == '=')
		{
			invalid = 1;
		}
		decodedLength -= invalid;
		decoded = new byte[decodedLength];

		int i = 0, di = 0;
		int sixbit0, sixbit1, sixbit2, sixbit3;

		for (; i < echars.length - 4; i += 4)
		{
			sixbit0 = decodeTable[echars[i    ]];
			sixbit1 = decodeTable[echars[i + 1]];
			sixbit2 = decodeTable[echars[i + 2]];
			sixbit3 = decodeTable[echars[i + 3]];

			decoded[di++] = (byte) ((sixbit0 << 2) + ((sixbit1 & 0x30) >> 4));
			decoded[di++] = (byte) (((sixbit1 & 0xF) << 4) + ((sixbit2 & 0x3C) >> 2));
			decoded[di++] = (byte) (((sixbit2 & 0x3) << 6) + sixbit3);
		}

		
		switch (invalid)
		{
			case 0 :
				sixbit0 = decodeTable[echars[i    ]];
				sixbit1 = decodeTable[echars[i + 1]];
				sixbit2 = decodeTable[echars[i + 2]];
				sixbit3 = decodeTable[echars[i + 3]];

				decoded[di++] = (byte) ((sixbit0 << 2) + ((sixbit1 & 0x30) >> 4));
				decoded[di++] = (byte) (((sixbit1 & 0xF) << 4) + ((sixbit2 & 0x3C) >> 2));
				decoded[di++] = (byte) (((sixbit2 & 0x3) << 6) + sixbit3);
				break;

			case 1 :
				sixbit0 = decodeTable[echars[i    ]];
				sixbit1 = decodeTable[echars[i + 1]];
				sixbit2 = decodeTable[echars[i + 2]];

				decoded[di++] = (byte) ((sixbit0 << 2) + ((sixbit1 & 0x30) >> 4));
				decoded[di++] = (byte) (((sixbit1 & 0xF) << 4) + ((sixbit2 & 0x3C) >> 2));
				break;

			case 2 :
				sixbit0 = decodeTable[echars[i    ]];
				sixbit1 = decodeTable[echars[i + 1]];

				decoded[di++] = (byte) ((sixbit0 << 2) + ((sixbit1 & 0x30) >> 4));
				break;
		}

		// assert decoded.length == di;
		return decoded;
	}

	public static byte[] url64_decode(byte[] ebytes)
	{

		try {
			char[] echars =  b2cs(URLDecoder.decode(new String(ebytes), "ksc5601").getBytes());
			return Base64.decode(echars);
			}catch(java.io.UnsupportedEncodingException ue){}
		return null;

	}

	public static byte[] url64_encode(byte[] ebytes)
	{
		char[] echars = Base64.encode(ebytes);
		try {
		return URLEncoder.encode(new String(echars), "ksc5601").getBytes();
		}catch(java.io.UnsupportedEncodingException ue){}

	return null;
	}
}
class TimerDeleteLog extends Thread
{
	private static int days = 0; 
	private String SS_LOG_HOME  = null;

 	public void run()
	{
		try {
			while(true)
			{
				deleteLogFile(days);
				Thread.sleep(1000*3600);
			}
																																	   			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	public TimerDeleteLog (int del_days, String log_home) 
	{
		this.days = del_days;				
		this.SS_LOG_HOME = log_home;				
	}

	private void deleteLogFile(int days)
	{
		String fnm = "deleteLogFile";

		try {

			long cmillis = System.currentTimeMillis();


			if (null == SS_LOG_HOME)
			{
				if (null == SS_LOG_HOME)
				{
					LUtil.println(fnm + " ERROR : "+SS_LOG_HOME);
					return;
				}
			}
	
			File dir = new File(SS_LOG_HOME);
			if (dir == null || !dir.isDirectory())
			{
				LUtil.println(fnm + " ERROR : "+SS_LOG_HOME);
				return;
			}
			/* Log 7day*/
			//deleteOldFiles(dir, (cmillis-604800000L), true, false);
			deleteOldFiles(dir, (cmillis-(86400000*days)), true, false);

		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void deleteOldFiles(File dir, long lastModified, boolean deleteSub, boolean deleteSubDir)
	{
		File[] fs = dir.listFiles();
		for(int i=0; i<fs.length; i++)
		{
			if (deleteSub && fs[i].isDirectory()) deleteOldFiles(fs[i], lastModified, true, deleteSubDir);

			if (fs[i].lastModified() < lastModified)
			{
				if (!fs[i].isDirectory() || deleteSubDir)
				{
					boolean rtn = fs[i].delete();
					//LUtil.println("====deleteOldFiles==== [" + rtn + ":"+fs[i].getName()+"]!!");
				}
			}
		}
	}
}
