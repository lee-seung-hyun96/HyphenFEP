#!/usr/bin/sh
ps -ef|grep KSNET_RVA_SERVICE |grep -v grep|awk '{print $2}'|xargs kill
