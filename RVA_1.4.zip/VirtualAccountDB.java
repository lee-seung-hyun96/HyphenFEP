package ksnet.ksrva;

import java.io.*;
import java.net.*;
import java.util.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;

import java.sql.*;

public class VirtualAccountDB extends Thread
{
	public static String Encrypt_Key = "12345678abcdefgh12345678";
	public static String Encoding = null;
	public static String LineType = null;
	public static String VrUpdateType = null;
	public static int MSG_LEN = 300;

	static String LOG_D = null;
	
	
	public static void main(String[] args) throws Exception
	{
		CUtil.setConfig(args[0]);
		
		LOG_D     = CUtil.get("LOG_DIR_PATH");
		File mkdirPath = new File(LOG_D);
		if(!mkdirPath.exists()) mkdirPath.mkdirs();
		

		/* Line Type */                             
		LineType = CUtil.get("COMM_LINE_TYPE");		/* Private Line; Y , Internet LIne: N */			
		if (LineType == null || LineType.length() == 0) LineType = "Y";
		
		/* Vr Account Auto Update */
		VrUpdateType = CUtil.get("AUTO_VR_UPDATE");
		if (VrUpdateType == null || VrUpdateType.length() == 0) VrUpdateType = "N";
		
		/* LISTEN Port */
		String LISTEN_PORT = CUtil.get("LISTEN_PORT");
		int port = Integer.parseInt(LISTEN_PORT);

		if (port == 0) throw new IllegalArgumentException("rve-config.ini LISTEN_PORT Error");

		Encoding = CUtil.get("ENCODING");
		if (Encoding == null || Encoding.length() == 0) Encoding = "ksc5601";

		LUtil.println("Process Start COMM_LINE_TYPE["+LineType+"] ENCODING["+Encoding+"] LISTEN_PORT["+LISTEN_PORT+"]");
				
		ServerSocket ss = new ServerSocket(port);
	
		while(true)
		{
			Socket  cs = ss.accept();
			new VirtualAccountDB(cs).start();
		}
	}

	Socket cs;
	public VirtualAccountDB(Socket cs)
	{
		this.cs = cs;
	}

	public void run()
	{
		DataOutputStream    out         = null;
		DataInputStream     in          = null;
		String              read_msg    = null;
		
		
		int read_len = 0, rtn_len = 0;

		try {

			in = new DataInputStream(cs.getInputStream());

			/* Internet line */
			if (LineType.equals("N") || LineType.equals("n") )
			{
				byte[]	read_buf = new byte[2048];
				byte[]	dec_read_buf = new byte[2048];
				byte[]	enc_send_buf = new byte[2048];
				byte[]	dec_send_buf = new byte[2048];


				if (0 >= (rtn_len = in.read(read_buf, read_len, 2048)))
				{
					throw new IOException("Read error - " + rtn_len + "read Byte!!");
				}
	
				read_len = read_len + rtn_len;
	
				byte[]  enc_read_buf = new byte[read_len];
				System.arraycopy(read_buf,0,enc_read_buf,0,read_len);
	
				dec_read_buf = EUtil.udecode_3des(Encrypt_Key.getBytes(), enc_read_buf);
	
				LUtil.println("RCV_MSG=[" + SUtil.toHanE(dec_read_buf, Encoding) + "]");
			
				dec_send_buf = parseMsg(dec_read_buf);

				enc_send_buf = EUtil.uencode_3des(Encrypt_Key.getBytes(), dec_send_buf);
	
				out = new DataOutputStream(cs.getOutputStream());
				out.write(enc_send_buf);
				out.flush();
	
				LUtil.println("SND_MSG=[" + SUtil.toHanE(dec_send_buf, Encoding) + "]");
			}
			/* private line */
			else
			{
				byte[]	read_buf = new byte[MSG_LEN];
				if (MSG_LEN != (rtn_len = in.read(read_buf, read_len, MSG_LEN)))
				{
					throw new IOException("Read error - " + rtn_len + "read Byte!!");
				}
	
				read_len = read_len + rtn_len;
	
				LUtil.println("RCV_MSG=[" + SUtil.toHanE(read_buf, Encoding) + "]");
	
				byte[] send_buf = parseMsg(read_buf);
	
				out = new DataOutputStream(cs.getOutputStream());
				out.write(send_buf);
				out.flush();
	
				LUtil.println("SND_MSG=[" + SUtil.toHanE(send_buf, Encoding) + "]");
			}

			
		}catch (Exception e) {
			LUtil.println(e.getMessage());
		}finally{
			try{if (in != null) in.close();}catch(Exception e){};
			try{if (out != null) out.close();}catch(Exception e){};
			try{if (cs != null) cs.close();}catch(Exception e){};
		}
	}

	public byte[] parseMsg(byte[] byte_data) throws Exception
	{
		boolean     ret = false;
		int         ipos = 0;
		HashMap<String,String> dHash = new HashMap<String,String>();
		HashMap<String,String> rHash = new HashMap<String,String>();
		

		if (byte_data[19] == '0' && byte_data[20] == '9' && byte_data[21] == '0' && byte_data[22] == '0')
		{
			String  send_date  = SUtil.toHanX(byte_data, 33, 8     );
			String  bank_code   = SUtil.toHanX(byte_data, 84, 3     );
			String  vr_acct_no   = SUtil.toHanX(byte_data, 100, 16   );
			String  amt         = SUtil.toHanX(byte_data, 170, 13   );
			String  corp_name 	= "";
			String  error_code = "L099";
			int     len;
			byte[] read_buf = (byte[])byte_data.clone();

			try {
				dHash.put("send_date", send_date);
				dHash.put("bank_code", bank_code);
				dHash.put("vr_acct_no", vr_acct_no);
				dHash.put("amt", amt);
	
				rHash = DUtil.select0900_100(dHash);

				if (rHash.containsKey("corp_name"))  corp_name = rHash.get("corp_name");
				if (rHash.containsKey("error_code")) error_code = rHash.get("error_code");
	
				byte[] b_resp_code = error_code.getBytes();
				byte[] b_corp_name = corp_name.getBytes("ksc5601");
				
				read_buf[19+2] = '1';
	
				System.arraycopy(b_resp_code, 0, read_buf, 47, b_resp_code.length);
				System.arraycopy(b_resp_code, 0, read_buf, 51, b_resp_code.length);
				System.arraycopy(b_corp_name, 0, read_buf, 116, b_corp_name.length);

			}
			catch(java.io.UnsupportedEncodingException ue){ue.printStackTrace();}
			
			return read_buf;
		}
		/* (0200/300) */
		else if (byte_data[19] == '0' && byte_data[20] == '2' && byte_data[21] == '0' && byte_data[22] == '0')
		{
			
			String  tran_code       = SUtil.toHanX(byte_data, ipos, 9   ); ipos +=  9 ;
			String  comp_code       = SUtil.toHanX(byte_data, ipos, 8   ); ipos +=  8 ;
			String  bank_code       = SUtil.toHanX(byte_data, ipos, 2   ); ipos +=  2 ;
			String  mess_code       = SUtil.toHanX(byte_data, ipos, 4   ); ipos +=  4 ;
			String  mess_diff       = SUtil.toHanX(byte_data, ipos, 3   ); ipos +=  3 ;
			String  tran_cnt        = SUtil.toHanX(byte_data, ipos, 1   ); ipos +=  1 ;
			String  seq_no          = SUtil.toHanX(byte_data, ipos, 6   ); ipos +=  6 ;
			String  tran_date       = SUtil.toHanX(byte_data, ipos, 8   ); ipos +=  8 ;
			String  tran_time       = SUtil.toHanX(byte_data, ipos, 6   ); ipos +=  6 ;
			String  stan_resp_code  = SUtil.toHanX(byte_data, ipos, 4   ); ipos +=  4 ;
			String  bank_resp_code  = SUtil.toHanX(byte_data, ipos, 4   ); ipos +=  4 ;
			String  inqu_date       = SUtil.toHanX(byte_data, ipos, 8   ); ipos +=  8 ;
			String  inqu_no         = SUtil.toHanX(byte_data, ipos, 6   ); ipos +=  6 ;
			String  bank_seq_no     = SUtil.toHanX(byte_data, ipos, 15  ); ipos +=  15;
			String  bank_code_3     = SUtil.toHanX(byte_data, ipos, 3   ); ipos +=  3 ;
			String  filler_1        = SUtil.toHanX(byte_data, ipos, 13  ); ipos +=  13;
			String  corp_acct_no     = SUtil.toHanX(byte_data, ipos, 15  ); ipos +=  15;
			String  comp_cnt        = SUtil.toHanX(byte_data, ipos, 2   ); ipos +=  2 ;
			String  deal_sele       = SUtil.toHanX(byte_data, ipos, 2   ); ipos +=  2 ;
			String  in_bank_code    = SUtil.toHanX(byte_data, ipos, 2   ); ipos +=  2 ;
			String  total_amt       = SUtil.toHanX(byte_data, ipos, 13  ); ipos +=  13;
			String  balance         = SUtil.toHanX(byte_data, ipos, 13  ); ipos +=  13;
			String  bran_code       = SUtil.toHanX(byte_data, ipos, 6   ); ipos +=  6 ;
			String  cust_name       = SUtil.toHanX(byte_data, ipos, 14  ); ipos +=  14;
			String  check_no        = SUtil.toHanX(byte_data, ipos, 10  ); ipos +=  10;
			String  cash            = SUtil.toHanX(byte_data, ipos, 13  ); ipos +=  13;
			String  out_bank_check  = SUtil.toHanX(byte_data, ipos, 13  ); ipos +=  13;
			String  etc_check       = SUtil.toHanX(byte_data, ipos, 13  ); ipos +=  13;
			String  vr_acct_no       = SUtil.toHanX(byte_data, ipos, 16  ); ipos +=  16;
			String  deal_date       = SUtil.toHanX(byte_data, ipos, 8   ); ipos +=  8 ;
			String  deal_time       = SUtil.toHanX(byte_data, ipos, 6   ); ipos +=  6 ;
			String  serial_no       = SUtil.toHanX(byte_data, ipos, 6   ); ipos +=  6 ;
			String  in_bank_code_3  = SUtil.toHanX(byte_data, ipos, 3   ); ipos +=  3 ;
			String  bran_code_3     = SUtil.toHanX(byte_data, ipos, 7   ); ipos +=  7 ;
			String  filler_2        = SUtil.toHanX(byte_data, ipos, 38  ); ipos +=  38;

			String  error_code = "9999";
			ret = DUtil.insert0200_300(tran_code,comp_code,bank_code,mess_code,mess_diff, tran_cnt,seq_no,tran_date,tran_time,stan_resp_code,bank_resp_code,inqu_date,inqu_no,bank_seq_no,bank_code_3,filler_1,corp_acct_no,comp_cnt,deal_sele,in_bank_code,total_amt,balance,bran_code,cust_name,check_no,cash,out_bank_check, etc_check,vr_acct_no,deal_date,deal_time,serial_no,in_bank_code_3,bran_code_3,filler_2);

			byte[] read_buf = (byte[])byte_data.clone();

			read_buf[19+2] = '1';

			if(ret) error_code = "0000";				

			byte[] b_resp_code = error_code.getBytes();

			System.arraycopy(b_resp_code, 0, read_buf, 47, b_resp_code.length);
			System.arraycopy(b_resp_code, 0, read_buf, 51, b_resp_code.length);

			return read_buf;
		}
		else if (byte_data[19] == '0' && byte_data[20] == '4' && byte_data[21] == '0' && byte_data[22] == '0')
		{
			String  tran_code       = SUtil.toHanX(byte_data, ipos, 9   ); ipos +=  9 ; 
			String  comp_code       = SUtil.toHanX(byte_data, ipos, 8   ); ipos +=  8 ; 
			String  bank_code       = SUtil.toHanX(byte_data, ipos, 2   ); ipos +=  2 ; 
			String  mess_code       = SUtil.toHanX(byte_data, ipos, 4   ); ipos +=  4 ; 
			String  mess_diff       = SUtil.toHanX(byte_data, ipos, 3   ); ipos +=  3 ; 
			String  tran_cnt        = SUtil.toHanX(byte_data, ipos, 1   ); ipos +=  1 ; 
			String  seq_no          = SUtil.toHanX(byte_data, ipos, 6   ); ipos +=  6 ; 
			String  tran_date       = SUtil.toHanX(byte_data, ipos, 8   ); ipos +=  8 ; 
			String  tran_time       = SUtil.toHanX(byte_data, ipos, 6   ); ipos +=  6 ; 
			String  stan_resp_code  = SUtil.toHanX(byte_data, ipos, 4   ); ipos +=  4 ; 
			String  bank_resp_code  = SUtil.toHanX(byte_data, ipos, 4   ); ipos +=  4 ; 
			String  inqu_date       = SUtil.toHanX(byte_data, ipos, 8   ); ipos +=  8 ; 
			String  inqu_no         = SUtil.toHanX(byte_data, ipos, 6   ); ipos +=  6 ; 
			String  bank_seq_no     = SUtil.toHanX(byte_data, ipos, 15  ); ipos +=  15; 
			String  bank_code_3     = SUtil.toHanX(byte_data, ipos, 3   ); ipos +=  3 ; 
			String  filler_1        = SUtil.toHanX(byte_data, ipos, 13  ); ipos +=  13; 
			String  org_seq_no      = SUtil.toHanX(byte_data, ipos, 6   ); ipos +=  6 ; 
			String  out_account_no  = SUtil.toHanX(byte_data, ipos, 15  ); ipos +=  15; 
			String  in_account_no   = SUtil.toHanX(byte_data, ipos, 15  ); ipos +=  15; 
			String  in_money        = SUtil.toHanX(byte_data, ipos, 13  ); ipos +=  13; 
			String  in_bank_code    = SUtil.toHanX(byte_data, ipos, 2   ); ipos +=  2 ; 
			String  nor_money       = SUtil.toHanX(byte_data, ipos, 13  ); ipos +=  13; 
			String  abnor_money     = SUtil.toHanX(byte_data, ipos, 13  ); ipos +=  13; 
			String  div_proc_cnt    = SUtil.toHanX(byte_data, ipos, 2   ); ipos +=  2 ; 
			String  div_proc_no     = SUtil.toHanX(byte_data, ipos, 2   ); ipos +=  2 ; 
			String  ta_no           = SUtil.toHanX(byte_data, ipos, 6   ); ipos +=  6 ; 
			String  not_in_amt      = SUtil.toHanX(byte_data, ipos, 9   ); ipos +=  9 ; 
			String  err_code        = SUtil.toHanX(byte_data, ipos, 3   ); ipos +=  3 ; 
			String  in_bank_code_3  = SUtil.toHanX(byte_data, ipos, 3   ); ipos +=  3 ; 
			String  filler_2        = SUtil.toHanX(byte_data, ipos, 98  ); ipos +=  98; 

			ret = DUtil.insert0400_100(tran_code, comp_code, bank_code, mess_code, mess_diff, tran_cnt, seq_no, tran_date, tran_time, stan_resp_code, bank_resp_code, inqu_date, inqu_no, bank_seq_no, bank_code_3, filler_1, org_seq_no, out_account_no, in_account_no, in_money, in_bank_code, nor_money, abnor_money, div_proc_cnt, div_proc_no, ta_no, not_in_amt, err_code, in_bank_code_3, filler_2);

			String  error_code = "9999";
			byte[] read_buf = (byte[])byte_data.clone();

			read_buf[19+2] = '1';

			if(ret) error_code = "0000";				

			byte[] b_resp_code = error_code.getBytes();

			System.arraycopy(b_resp_code, 0, read_buf, 47, b_resp_code.length);
			System.arraycopy(b_resp_code, 0, read_buf, 51, b_resp_code.length);

			return read_buf;
		}
		else if (byte_data[19] == '0' && byte_data[20] == '8' )
		{
			String  error_code = "0000";
			byte[] read_buf = (byte[])byte_data.clone();

			read_buf[19+2] = '1';

			byte[] b_resp_code = error_code.getBytes();

			System.arraycopy(b_resp_code, 0, read_buf, 47, b_resp_code.length);
			System.arraycopy(b_resp_code, 0, read_buf, 51, b_resp_code.length);

			return read_buf;
		}
		else
		{
			throw new RuntimeException("ERROR undefined MSG["+new String(byte_data)+"]");
		}
	}
}

class LUtil
{
	static String LOG_DIR = null;
	private static synchronized boolean init()
	{
		if (null == LOG_FILE || CUtil.isNew())
		{
			LOG_DIR     = CUtil.get("LOG_DIR_PATH");

			if (null == LOG_DIR) return false;
		}
		
		
		return true;
	}

	static Calendar LOG_CAL     = Calendar.getInstance();
	static String  LOG_DT       = null;
	static String  LOG_FILE     = null;

	private static synchronized void day_check(String curr_dt8)
	{
		if (LOG_DT == null || !LOG_DT.equals(curr_dt8))
		{
			File log_dir_file = new File(LOG_DIR);
			if (!log_dir_file.exists())log_dir_file.mkdirs();

			StringBuffer sb = new StringBuffer();

			sb.append(LOG_DIR);
			if (!LOG_DIR.endsWith("/") && !LOG_DIR.endsWith("\\")) sb.append("/");
			sb.append(curr_dt8);
			sb.append(".log");

			LOG_FILE = sb.toString();

			LOG_DT = curr_dt8;
		}
	}

	public static void println(Object pstr)
	{
		if (!init())
		{
			System.out.println("LOG_DIR_PATH Setting Error");
			return;
		}

		String curr_date = SUtil.getCurrDate();

		day_check(curr_date.substring(0,8));

		File openFile = new File(LOG_FILE);
		PrintStream out = null;

		try{
			if(openFile.exists()){
				out = new PrintStream(new FileOutputStream(LOG_FILE, true), true);
			}else{
				out = new PrintStream(new FileOutputStream(LOG_FILE), true);
			}

			if (pstr instanceof Throwable)
			{
				Throwable tw = (Throwable)pstr;
				tw.printStackTrace(out);
				out.println();
			}else{
				StringBuffer sb = new StringBuffer();

				sb.append("[");
				sb.append(curr_date.substring(8,10)).append(":").append(curr_date.substring(10,12)).append(":").append(curr_date.substring(12,14));
				sb.append("]" );
				sb.append(pstr);

				out.println(sb.toString());
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}finally {
			try{if (out != null) out.close();}catch(Exception e){};
		}
	}
}

class CUtil
{
	static String config_file = null;
	static long lastModified  = 0;

	public static Properties props = new Properties();

	public static synchronized void setConfig(String fpath)
	{
		if (!new File(fpath).exists()) throw new IllegalArgumentException("Cfg File Path Error=["+fpath+"]");
		config_file = fpath;
	}

	public static synchronized boolean isNew()
	{
		try
		{
			File f = new File(config_file);
			long m_lastModified = f.lastModified();

			if (m_lastModified > lastModified + 2000)
			{
				props.load(new FileInputStream(f));

				lastModified = m_lastModified;

				return true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}

	public static String get(String kStr)
	{
		isNew();
		return props.getProperty(kStr);
	}
}

class DUtil
{
	static String DRIVER_NAME   = null;
	static String DB_URL        = null;
	static String USER_NAME     = "";
	static String PASSWORD      = "";

	public static Connection getConnection()
	{
		if (null == DRIVER_NAME || CUtil.isNew())
		{
			DRIVER_NAME = CUtil.get("JDBC_DRIVER"   );
			DB_URL      = CUtil.get("JDBC_URL"      );
			USER_NAME   = CUtil.get("JDBC_USER"     );
			PASSWORD    = CUtil.get("JDBC_PASSWORD" );

			if (USER_NAME   == null) USER_NAME  = "";
			if (PASSWORD    == null) PASSWORD   = "";
		}

		try{
			Class.forName (DRIVER_NAME);
			if (USER_NAME == null || USER_NAME.length() == 0)
				return DriverManager.getConnection(DB_URL);
			else
				return DriverManager.getConnection(DB_URL, USER_NAME, PASSWORD);
		}catch(Exception e){
			LUtil.println(e);
		}
		return null;
	}

	public static HashMap<String,String> select0900_100 (HashMap<String,String> dHash)
	{
		Connection          con     = null;
		PreparedStatement   pstmt   = null;
		ResultSet rs = null;

		int cnt = 0;
		String SEL_QRY = "";

		String 	corp_name = "";
		String 	final_date = "";
		String 	chkFlag = "";
		String 	db_amt = "";
		double 	d_db_amt = 0;
		double 	d_amt = 0;
		
		String  send_date  	= dHash.get("send_date");
		String  bank_code		= dHash.get("bank_code");
		String  vr_acct_no 	= dHash.get("vr_acct_no");
		String  amt         = dHash.get("amt");
		
		HashMap<String,String> rHash = new HashMap<String,String>();
		
		rHash.put("error_code", "L099");

		/* check account */
		SEL_QRY = "SELECT CORP_NAME, AMT, FINAL_DATE FROM KSNET_VR_ACCOUNT WHERE BANK_CODE = ? AND VR_ACCT_NO = ? AND USE_FLAG = 'Y' ";

		try {
			con = getConnection();
			con.setAutoCommit(false);

			pstmt = con.prepareStatement(SEL_QRY);

			LUtil.println("DEBUG 0900/100 search BANKCODE[" + bank_code + "], VR_ACC[" + vr_acct_no + "], AMT[" + amt + "], SEND_DATE[" + send_date + "]");

			d_amt = Long.parseLong(amt);
			
			pstmt.setString (1, bank_code     );
			pstmt.setString (2, vr_acct_no     );

			rs = pstmt.executeQuery();

			while (rs.next()) {
				cnt++;
				corp_name = rs.getString(1);
				db_amt = rs.getString(2);
				d_db_amt = Long.parseLong(db_amt);
				final_date = rs.getString(3);

				break;
			}
			
			if(final_date.equals(""))
			{
				final_date = "99991231";
			}
			
			if (cnt < 1)
			{
				LUtil.println( "ERROR 0900/100 Not found information  bank_code("+bank_code+") account_no("+vr_acct_no+")");
				rHash.put("error_code", "L008");   /* not found account */
			}
			else if (d_db_amt > 0 && d_amt != d_db_amt)
			{
				LUtil.println( "ERROR 0900/100 mismatch amt!  bank_code("+bank_code+") account_no("+vr_acct_no+") amount("+amt+") db_amount("+db_amt+")");
				rHash.put("error_code", "L002");

			}
			else if (Integer.parseInt(final_date) < Integer.parseInt(send_date))
			{
				LUtil.println( "ERROR 0900/100 final date!  bank_code("+bank_code+") account_no("+vr_acct_no+") final_date("+final_date+")");
				rHash.put("error_code", "L004");  
			}
			else 
			{
				rHash.put("error_code", "0000");  
				rHash.put("corp_name", corp_name);  
			}
	
		}catch(Throwable e) {
			LUtil.println(e);
		} finally {
			try {if(pstmt!=null){pstmt.close();pstmt= null;}}catch(Exception e){}
			try {if(con !=null) {con.close( );/*con = null;*/}}catch(Exception e){}
			try {if(rs !=null) {rs.close( ); rs = null;}}catch(Exception e){}
		}
		
		return rHash;
	}

	
	public static boolean insert0200_300(String tran_code,String comp_code,String bank_code,String mess_code,String mess_diff,String tran_cnt,String seq_no,String tran_date,String tran_time,String stan_resp_code,String bank_resp_code,String inqu_date,String inqu_no,String bank_seq_no,String bank_code_3,String filler_1,String corp_acct_no,String comp_cnt,String deal_sele,String in_bank_code,String total_amt,String balance,String bran_code,String cust_name,String check_no,String cash,String out_bank_check,String etc_check,String vr_acct_no,String deal_date,String deal_time,String serial_no,String in_bank_code_3,String bran_code_3,String filler_2)
	{
		Connection        con   = null;
		PreparedStatement pstmt = null;

		String  INS2_QRY = "INSERT INTO KSNET_TRADE_DATA (tran_code,comp_code,bank_code,mess_code,mess_diff, tran_cnt,seq_no,tran_date,tran_time,stan_resp_code,bank_resp_code,inqu_date,inqu_no,bank_seq_no,filler_1,corp_acct_no,comp_cnt,deal_sele,in_bank_code,total_amt,balance,bran_code,cust_name,check_no,cash,out_bank_check, etc_check,vr_acct_no,deal_date,deal_time,serial_no,filler_2) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		String  INS3_QRY = "UPDATE KSNET_VR_ACCOUNT SET USE_FLAG = 'N' WHERE BANK_CODE = ? AND VR_ACCT_NO = ? AND AMT = ? AND USE_FLAG = 'Y'";
			
		try {
			con = getConnection();
			con.setAutoCommit(false);

			pstmt = con.prepareStatement(INS2_QRY);

			pstmt.setString (1,  tran_code     );
			pstmt.setString (2,  comp_code     );
			pstmt.setString (3,  bank_code_3   );
			pstmt.setString (4,  mess_code     );
			pstmt.setString (5,  mess_diff     );
			pstmt.setString (6,  tran_cnt      );
			pstmt.setString (7,  seq_no        );
			pstmt.setString (8,  tran_date     );
			pstmt.setString (9,  tran_time     );
			pstmt.setString (10, stan_resp_code);
			pstmt.setString (11, bank_resp_code);
			pstmt.setString (12, inqu_date     );
			pstmt.setString (13, inqu_no       );
			pstmt.setString (14, bank_seq_no   );
			pstmt.setString (15, filler_1      );
			pstmt.setString (16, corp_acct_no   );
			pstmt.setString (17, comp_cnt      );
			pstmt.setString (18, deal_sele     );
			pstmt.setString (19, in_bank_code_3);
			pstmt.setString (20, total_amt     );
			pstmt.setString (21, balance       );
			pstmt.setString (22, bran_code_3   );
			pstmt.setString (23, cust_name     );
			pstmt.setString (24, check_no      );
			pstmt.setString (25, cash          );
			pstmt.setString (26, out_bank_check);
			pstmt.setString (27, etc_check     );
			pstmt.setString (28, vr_acct_no     );
			pstmt.setString (29, deal_date     );
			pstmt.setString (30, deal_time     );
			pstmt.setString (31, serial_no     );
			pstmt.setString (32, filler_2      );
			
			pstmt.executeUpdate();
			
			if (VirtualAccountDB.VrUpdateType.equals("Y") && Long.parseLong(total_amt) > 0)
			{
				pstmt = con.prepareStatement(INS3_QRY);	
				pstmt.setString (1, bank_code_3   );
				pstmt.setString (2, vr_acct_no     );
				pstmt.setString (3, total_amt     );
				pstmt.executeUpdate();
			}
			

			con.commit();
			return true;

		}catch(Throwable e) {
			int sql_code = 0;
			if (e instanceof SQLException)  /* case 1: ORA-00001 */
			{
				sql_code = ((SQLException)e).getErrorCode();
			}
			try{con.rollback();}catch(SQLException se){}

			if(sql_code == 1){
				LUtil.println("Oracle duplicate keys");
				return true;
			}
			else if (sql_code == -239){
				LUtil.println("Informix duplicate keys");
				return true;
			}
			else if (sql_code == 2627 || sql_code == 2601){
				LUtil.println("MSSQL duplicate keys");
				return true;
			}
			else if (sql_code == 1062){
				LUtil.println("MYSQL duplicate keys");
				return true;
			}
			else if (sql_code == -803){
				LUtil.println("DB2 duplicate keys");
				return true;
			}

			LUtil.println(e);

		} finally {
			try {if(pstmt != null){pstmt.close();pstmt = null;}}catch(Exception e){}
			try {if(con != null) {con.close( );/*con = null;*/}}catch(Exception e){}
		}
		return false;
	}
	public static boolean insert0400_100(String tran_code, String comp_code, String bank_code, String mess_code, String mess_diff, String tran_cnt, String seq_no, String tran_date, String tran_time, String stan_resp_code, String bank_resp_code, String inqu_date, String inqu_no, String bank_seq_no, String bank_code_3, String filler_1, String org_seq_no, String out_account_no, String in_account_no, String in_money, String in_bank_code, String nor_money, String abnor_money, String div_proc_cnt, String div_proc_no, String ta_no, String not_in_amt, String err_code, String in_bank_code_3, String filler_2)
	{
		Connection          con     = null;
		PreparedStatement   pstmt   = null;

		String  INS4_QRY = "INSERT INTO KSNET_TRADE_ERR (tran_code, comp_code, bank_code, mess_code, mess_diff, tran_cnt, seq_no, tran_date, tran_time, stan_resp_code, bank_resp_code, inqu_date, inqu_no, bank_seq_no, filler_1, org_seq_no, out_account_no, in_account_no, in_money, in_bank_code, nor_money, abnor_money, div_proc_cnt, div_proc_no, ta_no, not_in_amt, err_code, filler_2) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		try {
			con = getConnection();
			con.setAutoCommit(false);

			pstmt   = con.prepareStatement(INS4_QRY);

			pstmt.setString (1,  tran_code     );
			pstmt.setString (2,  comp_code     );
			pstmt.setString (3,  bank_code_3     );
			pstmt.setString (4,  mess_code     );
			pstmt.setString (5,  mess_diff     );
			pstmt.setString (6,  tran_cnt      );
			pstmt.setString (7,  seq_no        );
			pstmt.setString (8,  tran_date     );
			pstmt.setString (9,  tran_time     );
			pstmt.setString (10, stan_resp_code);
			pstmt.setString (11, bank_resp_code);
			pstmt.setString (12, inqu_date     );
			pstmt.setString (13, inqu_no       );
			pstmt.setString (14, bank_seq_no   );
			pstmt.setString (15, filler_1      );
			pstmt.setString (16, org_seq_no    );
			pstmt.setString (17, out_account_no);
			pstmt.setString (18, in_account_no );
			pstmt.setString (19, in_money      );
			pstmt.setString (20, in_bank_code_3  );
			pstmt.setString (21, nor_money     );
			pstmt.setString (22, abnor_money   );
			pstmt.setString (23, div_proc_cnt  );
			pstmt.setString (24, div_proc_no   );
			pstmt.setString (25, ta_no         );
			pstmt.setString (26, not_in_amt    );
			pstmt.setString (27, err_code      );
			pstmt.setString (28, filler_2      );

			pstmt.executeUpdate();

			con.commit();

			return true;

		}catch(Throwable e) {
			int sql_code = 0;
			if (e instanceof SQLException)  /* case 1: ORA-00001 (duplicate keys) */
			{
				sql_code = ((SQLException)e).getErrorCode();
			}
			try{con.rollback();}catch(SQLException se){}

			if(sql_code == 1){
				LUtil.println("Oracle duplicate keys");
				return true;
			}
			else if (sql_code == -239){
				LUtil.println("Informix duplicate keys");
				return true;
			}
			else if (sql_code == 2627 || sql_code == 2601){
				LUtil.println("MSSQL duplicate keys");
				return true;
			}
			else if (sql_code == 1062){
				LUtil.println("MYSQL duplicate keys");
				return true;
			}
			else if (sql_code == -803){
				LUtil.println("DB2 duplicate keys");
				return true;
			}

			LUtil.println(e);

		} finally {
			try {if(pstmt!=null){pstmt.close();pstmt= null;}}catch(Exception e){}
			try {if(con !=null) {con.close( );/*con = null;*/}}catch(Exception e){}
		}
		return false;
	}
}

class SUtil
{
	static String getCurrDate()
	{
		Calendar cal = Calendar.getInstance();
		StringBuffer sb = new StringBuffer();
		int li_yyyy,li_MM,li_dd,li_hour,li_min,li_sec;

		li_yyyy = cal.get(Calendar.YEAR); li_MM = cal.get(Calendar.MONTH); li_dd = cal.get(Calendar.DATE);
		li_hour = cal.get(Calendar.HOUR_OF_DAY); li_min = cal.get(Calendar.MINUTE); li_sec = cal.get(Calendar.SECOND);

		//sb.append(Integer.toString(li_yyyy)).append(li_MM<9 ? "0" : "").append(Integer.toString(li_MM + 1)).append(li_dd<10 ? "0" : "").append(Integer.toString(li_dd));
		//sb.append(li_yyyy+"").append(li_MM<9 ? "0" : "").append(li_MM + 1+"").append(li_dd<10 ? "0" : "").append(li_dd+""); 
		sb.append(li_yyyy).append(li_MM<9 ? "0" : "").append(li_MM + 1).append(li_dd<10 ? "0" : "").append(li_dd);
		sb.append(li_hour<10 ? "0" : "").append(li_hour).append(li_min<10 ? "0" : "").append(li_min).append(li_sec<10 ? "0" : "").append(li_sec);

		return sb.toString();
	}

	static String toHanX(byte[] bsrc, int idx, int len)
	{
		String str = toHan(bsrc, idx, len);
		if (str == null) return null;

		return str.trim();
	}

	static String toHan(byte[] bsrc, int idx, int len)
	{
		try
		{
			return new String(bsrc, idx, len ,"ksc5601");
		}catch(java.io.UnsupportedEncodingException ue){}

		return null;
	}
	
	static String toHanE(byte[] bsrc, String encoding_type)
	{
		try
		{
			String buf = new String(bsrc, "ksc5601");
			byte[] buf_enc = buf.getBytes(encoding_type);
			
			return new String(bsrc, encoding_type);
			
		}catch(java.io.UnsupportedEncodingException ue){}

		return null;
	}

	static String toHanE(byte[] bsrc, int idx, int len, String encoding_type)
	{
		try
		{
			String buf = new String(bsrc, idx, len, "ksc5601");
			byte[] buf_enc = buf.getBytes(encoding_type);
			
			return new String(bsrc, encoding_type);
			
		}catch(java.io.UnsupportedEncodingException ue){}

		return null;
	}

	public static String[] split(String srcStr, char c1)
	{
		return split(srcStr, String.valueOf(c1));
	}

	public static String[] split(String srcStr, String str1)
	{
		if (srcStr == null) return new String[0];

		String[] tokenArr = null;
		if (srcStr.indexOf(str1) == -1)
		{
			tokenArr = new String[1];
			tokenArr[0] = srcStr;

			return tokenArr;
		}

		LinkedList<String> linkedlist = new LinkedList<String>();

		int srcLength    = srcStr.length();
		int tockenLength = str1.length();

		int pos = 0, startPos = 0;
		while(startPos < srcLength)
		{
			pos = srcStr.indexOf(str1, startPos);

			if (-1 == pos) break;

			linkedlist.add(srcStr.substring(startPos, pos));
			startPos = pos + tockenLength;
		}

		if (startPos <= srcLength) linkedlist.add(srcStr.substring(startPos));

		return (String[])linkedlist.toArray(new String[0]);
	}//split

}


class EUtil
{
	public static byte[] udecode_3des(byte[] b_key, byte[] ebytes) throws NoSuchAlgorithmException, InvalidKeyException,
			IllegalBlockSizeException, NoSuchPaddingException, BadPaddingException, IOException
	{
		SecretKeySpec skeySpec = new SecretKeySpec(b_key, "DESede");
		Cipher cipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");

		cipher.init(Cipher.DECRYPT_MODE, skeySpec);
		byte[] b_emsg = Base64.url64_decode(ebytes);
		byte[] b_dmsg = cipher.doFinal(b_emsg);

		return b_dmsg;
	}

	public static byte[] uencode_3des(byte[] b_key, byte[] pbytes) throws NoSuchAlgorithmException, InvalidKeyException,
			IllegalBlockSizeException, NoSuchPaddingException, BadPaddingException, IOException
	{
		SecretKeySpec skeySpec = new SecretKeySpec(b_key, "DESede");
		Cipher cipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");

		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		byte[] b_emsg = cipher.doFinal(pbytes);
		byte[] b_bmsg = Base64.url64_encode(b_emsg);

		return b_bmsg;
	}
}



class Base64
{
	
	protected static final char[] alphabet = {
		'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', // 0 to 7
		'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', // 8 to 15
		'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', // 16 to 23
		'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', // 24 to 31
		'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', // 32 to 39
		'o', 'p', 'q', 'r', 's', 't', 'u', 'v', // 40 to 47
		'w', 'x', 'y', 'z', '0', '1', '2', '3', // 48 to 55
		'4', '5', '6', '7', '8', '9', '+', '/'  // 56 to 63
	};

	protected static final int[] decodeTable = {
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 0 to 9
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 10 to 19
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 20 to 29
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, // 30 to 39
		-1, -1, -1, 62, -1, -1, -1, 63, 52, 53, // 40 to 49
		54, 55, 56, 57, 58, 59, 60, 61, -1, -1, // 50 to 59
		-1, -1, -1, -1, -1,  0,  1,  2,  3,  4, // 60 to 69
		 5,  6,  7,  8,  9, 10, 11, 12, 13, 14, // 70 to 79
		15, 16, 17, 18, 19, 20, 21, 22, 23, 24, // 80 to 89
		25, -1, -1, -1, -1, -1, -1, 26, 27, 28, // 90 to 99
		29, 30, 31, 32, 33, 34, 35, 36, 37, 38, // 100 to 109
		39, 40, 41, 42, 43, 44, 45, 46, 47, 48, // 110 to 119
		49, 50, 51                              // 120 to 122
	};

	public static char[] encode(String s) {
		return encode(s.getBytes());
	}

	/**
	 * convert bytes into a BASE64 encoded string
	 */
	public static char[] encode(byte[] bytes)
	{
		int sixbit;

		char[] output = new char[((bytes.length - 1) / 3 + 1) * 4];

		int outIndex = 0;
		int i = 0;

		while ((i + 3) <= bytes.length)
		{
			sixbit = (bytes[i] & 0xFC) >> 2;
			output[outIndex++] = alphabet[sixbit];

			sixbit = ((bytes[i] & 0x3) << 4) + ((bytes[i + 1] & 0xF0) >> 4);
			output[outIndex++] = alphabet[sixbit];

			sixbit = ((bytes[i + 1] & 0xF) << 2) + ((bytes[i + 2] & 0xC0) >> 6);
			output[outIndex++] = alphabet[sixbit];

			sixbit = bytes[i + 2] & 0x3F;
			output[outIndex++] = alphabet[sixbit];

			i += 3;
		}

		if (bytes.length - i == 2)
		{
			
			sixbit = (bytes[i] & 0xFC) >> 2;
			output[outIndex++] = alphabet[sixbit];

			
			sixbit = ((bytes[i] & 0x3) << 4) + ((bytes[i + 1] & 0xF0) >> 4);
			output[outIndex++] = alphabet[sixbit];

			
			sixbit = (bytes[i + 1] & 0xF) << 2;
			output[outIndex++] = alphabet[sixbit];

			
			output[outIndex++] = '=';
		} else
		if (bytes.length - i == 1) 
		{
			
			sixbit = (bytes[i] & 0xFC) >> 2;
			output[outIndex++] = alphabet[sixbit];

			
			sixbit = (bytes[i] & 0x3) << 4;
			output[outIndex++] = alphabet[sixbit];

			
			output[outIndex++] = '=';
			
			output[outIndex++] = '=';
		}

		return output;
	}

	public static char[] b2cs(byte[] ebytes)
	{
		char[] echars = new char[ebytes.length];
		for(int i=0; i<echars.length; i++) echars[i] = (char)ebytes[i];

		return echars;
	}

	public static byte[] c2bs(char[] echars)
	{
		byte[] ebytes = new byte[echars.length];
		for(int i=0; i<echars.length; i++) ebytes[i] = (byte)echars[i];

		return ebytes;
	}

	public static byte[] decode(byte[] ebytes)
	{
		return decode(b2cs(ebytes));
	}

	public static byte[] decode(String encoded)
	{
		return decode(encoded.toCharArray());
	}

	public static byte[] decode(char[] echars)
	{
		byte[] decoded = null;
		int decodedLength = (echars.length / 4 * 3);
		int invalid = 0;

		if (echars.length % 4 != 0)
		{
			System.err.println("It's not BASE64 encoded string.");
			return null;
		}
		if (echars[echars.length - 2] == '=')
		{
			invalid = 2;
		} else
		if (echars[echars.length - 1] == '=')
		{
			invalid = 1;
		}
		decodedLength -= invalid;
		decoded = new byte[decodedLength];

		int i = 0, di = 0;
		int sixbit0, sixbit1, sixbit2, sixbit3;

		for (; i < echars.length - 4; i += 4)
		{
			sixbit0 = decodeTable[echars[i    ]];
			sixbit1 = decodeTable[echars[i + 1]];
			sixbit2 = decodeTable[echars[i + 2]];
			sixbit3 = decodeTable[echars[i + 3]];

			decoded[di++] = (byte) ((sixbit0 << 2) + ((sixbit1 & 0x30) >> 4));
			decoded[di++] = (byte) (((sixbit1 & 0xF) << 4) + ((sixbit2 & 0x3C) >> 2));
			decoded[di++] = (byte) (((sixbit2 & 0x3) << 6) + sixbit3);
		}

		
		switch (invalid)
		{
			case 0 :
				sixbit0 = decodeTable[echars[i    ]];
				sixbit1 = decodeTable[echars[i + 1]];
				sixbit2 = decodeTable[echars[i + 2]];
				sixbit3 = decodeTable[echars[i + 3]];

				decoded[di++] = (byte) ((sixbit0 << 2) + ((sixbit1 & 0x30) >> 4));
				decoded[di++] = (byte) (((sixbit1 & 0xF) << 4) + ((sixbit2 & 0x3C) >> 2));
				decoded[di++] = (byte) (((sixbit2 & 0x3) << 6) + sixbit3);
				break;

			case 1 :
				sixbit0 = decodeTable[echars[i    ]];
				sixbit1 = decodeTable[echars[i + 1]];
				sixbit2 = decodeTable[echars[i + 2]];

				decoded[di++] = (byte) ((sixbit0 << 2) + ((sixbit1 & 0x30) >> 4));
				decoded[di++] = (byte) (((sixbit1 & 0xF) << 4) + ((sixbit2 & 0x3C) >> 2));
				break;

			case 2 :
				sixbit0 = decodeTable[echars[i    ]];
				sixbit1 = decodeTable[echars[i + 1]];

				decoded[di++] = (byte) ((sixbit0 << 2) + ((sixbit1 & 0x30) >> 4));
				break;
		}

		// assert decoded.length == di;
		return decoded;
	}

	public static byte[] url64_decode(byte[] ebytes)
	{

		try {
			char[] echars =  b2cs(URLDecoder.decode(new String(ebytes), "ksc5601").getBytes());
			return Base64.decode(echars);
			}catch(java.io.UnsupportedEncodingException ue){}
		return null;

	}

	public static byte[] url64_encode(byte[] ebytes)
	{
		char[] echars = Base64.encode(ebytes);
		try {
		return URLEncoder.encode(new String(echars), "ksc5601").getBytes();
		}catch(java.io.UnsupportedEncodingException ue){}

	return null;
	}
}

