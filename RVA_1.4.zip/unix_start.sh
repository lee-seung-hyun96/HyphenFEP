#!/usr/bin/sh

JAVA_HOME=/usr/java6_64
INSTALL_HOME=`pwd`
CONIFG_FILE=$INSTALL_HOME/conf/config.ini

CLASSPATH=$INSTALL_HOME:$INSTALL_HOME/lib/sqljdbc.jar:$INSTALL_HOME/lib/ojdbc14.jar:$INSTALL_HOME/lib/mysql-connector-java-5.1.6-bin.jar

nohup $JAVA_HOME/bin/java -DKSNET_RVA_SERVICE -classpath $CLASSPATH ksnet.ksrva.VirtualAccountDB $CONIFG_FILE & 
